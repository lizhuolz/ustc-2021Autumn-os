#ifndef __TYPES__H__
#define __TYPES__H__

#define NULL (void *)0

#endif