#include "shell.h"
#include "memTestCase.h"

void myMain(void) {

    initShell();
    memTestCaseInit();
    startShell();

}
