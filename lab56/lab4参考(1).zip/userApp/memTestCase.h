#ifndef __MEM_TEST_CASE_H__
#define __MEM_TEST_CASE_H__

void memTestCaseInit(void);

#endif