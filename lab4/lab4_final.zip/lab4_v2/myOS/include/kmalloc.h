#ifndef __KMALLOC_H__
#define __KMALLOC_H__

#include "mem.h"

//需要实现！！！（可选）
	/*
	这里实现kmalloc/kfree，调用dp或者是efp里的函数实现即可
	*/

#endif